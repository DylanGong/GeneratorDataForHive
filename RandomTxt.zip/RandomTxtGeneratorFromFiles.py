import random
"""
实现从文件中读取数据，随机生成txt文件
"""

# 定义可能的分隔符
DELIMITERS = [",", ";", "|", "\t"]  # 您可以添加更多分隔符
def generate_random_delimiter():
    """生成一个随机的分隔符（在整个文件中固定使用）"""
    return random.choice(DELIMITERS)


def load_city_data(file_path):
    """从文件加载城市、街道、邮政编码数据"""
    city_data = {}
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            line = line.strip()
            if not line or line.startswith("#"):
                continue  # 跳过空行和注释
            street,district,city,zip = line.split(",")
            if city not in city_data:
                city_data[city] = []
            city_data[city].append({"street": street, "zip": int(zip),"district":district})
    return city_data



def generate_unique_student_ids(num_ids, min_id=100000, max_id=999999):
    """
    生成指定数量的不重复学号。
    """
    # 检查学号范围是否足够
    if num_ids > (max_id - min_id + 1):
        raise ValueError("学号范围不足以生成指定数量的不重复学号")
    unique_ids = set()  # 使用集合来存储不重复的学号
    while len(unique_ids) < num_ids:
        # 生成一个随机学号，并确保它不在集合中
        new_id = random.randint(min_id, max_id)
        while new_id in unique_ids:  # 这里的内部while循环是为了处理随机生成的学号可能重复的情况
            new_id = random.randint(min_id, max_id)
        unique_ids.add(new_id)  # 将新生成的学号添加到集合中
    # 将集合转换为列表并返回
    return list(unique_ids)




def load_names(file_path):
    """从文件加载姓名数据"""
    names = []
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            line = line.strip()
            if not line or line.startswith("#"):
                continue  # 跳过空行和注释
            name = line.split(",")
            names.append(name)
    return names

def Parent_name(file_path):
    """从文件加载姓名数据"""
    names = []
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            line = line.strip()
            if not line or line.startswith("#"):
                continue  # 跳过空行和注释
            name = line.split(",")
            names.append(name)
    return names


def generate_random_txt(name_pool,Parent_name_pool,delimiter):
    """生成一个随机的 txt 数据"""
    # 随机选择 name，确保不重复
    name = random.choice(name_pool)
    name_pool.remove(name)
    sid = random.choice(generate_unique_student_ids(1))
    age = random.randint(18, 25)  # 生成一个18到25岁之间的随机年龄
    height = random.randint(150, 180)  # 生成一个150到180厘米之间的随机身高
    class_ = random.randint(1, 3)  #随机班级
    # 随机选择 父母名称，确保不重复
    Parent_name = random.choice(Parent_name_pool)
    Parent_name_pool.remove(Parent_name)
    # 随机选择一个城市和对应的街道、邮政编码
    city = random.choice(list(city_data.keys()))
    address_data = random.choice(city_data[city])

    street=address_data["street"]
    district=address_data["district"]
    city= city
    zip=address_data["zip"]


    # 随机家庭关系
    family_ties_data=["父子","母子","爷孙","姐弟","姐妹","兄妹"]
    family_ties_random = random.choice(family_ties_data)

    # 组装地址信息
    address_info = f"street:{street}-district:{district}-city:{city}-zip:{zip}"
    # 组装完整的 txt 数据
    record_parts = [
        str(sid),
        name[0],
        str(age),
        str(height),
        str(class_),
        address_info,
        f"{family_ties_random}:{Parent_name[0]}"
    ]
    record = delimiter.join(record_parts)
    return record


if __name__ == "__main__":
    # 文件路径
    city_data_file = "street-district-city-zip.txt"
    name_file = "name_gender.txt"
    Parent_name_file = "Parent's name.txt"
    output_file = "output.txt"

    # 加载数据
    city_data = load_city_data(city_data_file)
    name_pool = load_names(name_file)
    Parent_name_pool = Parent_name(Parent_name_file)
    # 生成一个固定的随机分隔符
    fixed_delimiter = generate_random_delimiter()

    # 将结果保存到文件
    with open(output_file, 'w', encoding='utf-8') as file:
        for _ in range(10):
            random_txt = generate_random_txt(name_pool.copy(),Parent_name_pool.copy(),fixed_delimiter)
            file.write(random_txt + '\n')
    print(f"生成的 txt 数据已保存到 {output_file}")